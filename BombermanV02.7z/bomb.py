from PyQt5.QtGui import QColor
import map
from constants import SET_BOMBS
import constants
from explosion import Explosion


class Bomb:
    """
    Класс реализующий объект Bomb. Содержит все методы и свойства описывающие Bomb.
    """
    def __init__(self):
        self.player = None
        self.position = None
        self.color = QColor(128, 0, 0)
        self.timer = 10
        self.anim = False
        self.assets = True

    def ticker(self):
        """
        Метод - счётчик для бомбы, если счётчик 0 - вызывает Boom
        :return: None
        """
        self.timer -= 1
        if self.timer < 0:
            self.boom()
        else:
            return

    def boom(self):
        """
        Метод - взрыв бомбы.
        :return: None
        """
        is_explosion = Explosion(self.position, self)
        is_explosion.explosion_region()
        #   print('Взрыв')
        self.remove() # ремув будет в map при удалении блока == бромбы

    def remove(self):
        """
        Метод удаляет бомбу из Множества бомб и Объектной карты после взрыва.
        :return: None
        """
        map.set_object(self.position, None)
        constants.SET_BOMBS.discard(self)
        self.player.refresh_bomb()


class SimpleBomb(Bomb):
    """
    Класс реализующий объект SimpleBomb. Содержит методы Bomb и свойства SimpleBomb.
    """
    def __init__(self, position, player, power_bomb):
        super().__init__()
        self.position = position
        self.player = player
        self.power_bomb = power_bomb
        self.color = QColor(255, 46, 0)
        self.timer = 5


class Mine(Bomb):
    """
    Класс реализующий объект GreenBomb. Содержит методы Bomb и свойства GreenBomb.
    (Урона больше)
    """
    def __init__(self, position, player, power_bomb=2):
        super().__init__()
        self.position = position
        self.player = player
        self.power_bomb = power_bomb
        self.color = QColor(0, 144, 0)
        self.assets = False
