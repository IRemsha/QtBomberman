from PyQt5.QtCore import QSize
from PyQt5.QtGui import QMovie, QPainter, QFontMetrics
from PyQt5.QtWidgets import QLabel, QApplication


class QTextMovieLabel(QLabel):
    def __init__(self, text, fileName):
        QLabel.__init__(self)
        self._text = text
        m = QMovie(fileName)
        m.start()
        self.setMovie(m)

    def setMovie(self, movie):
        QLabel.setMovie(self, movie)
        s=movie.currentImage().size()
        self._movieWidth = s.width()
        self._movieHeight = s.height()
